import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTextPane;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButton;

public class WelcomeWindow implements ActionListener {

	private JFrame frame;
	private JPanel panel1,panel2;
	private JTextField textField;
	private JTextField textField_1;
	private JButton btnTermsAndServices;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					WelcomeWindow window = new WelcomeWindow();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public WelcomeWindow()  {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Welcome to OSCN , we are glad that you trust us .");
		lblNewLabel.setFont(new Font("Krungthep", Font.PLAIN, 14));
		lblNewLabel.setBounds(24, 6, 374, 29);
		frame.getContentPane().add(lblNewLabel);
		
		JButton btnGo = new JButton("GO !");
		btnGo.setBounds(164, 226, 117, 29);
		frame.getContentPane().add(btnGo);
		
		textField = new JTextField();
		textField.setBounds(247, 66, 153, 29);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(247, 116, 153, 29);
		frame.getContentPane().add(textField_1);
		
		JLabel lblUsername = new JLabel("Username");
		lblUsername.setBounds(164, 72, 71, 16);
		frame.getContentPane().add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(164, 122, 71, 16);
		frame.getContentPane().add(lblPassword);
		
		JCheckBox agreeChckBx = new JCheckBox("Agree on terms and sevices");
		agreeChckBx.setFont(new Font("Lucida Grande", Font.PLAIN, 11));
		agreeChckBx.setBounds(241, 156, 191, 23);
		frame.getContentPane().add(agreeChckBx);
		
		 btnTermsAndServices = new JButton("Terms and services");
		btnTermsAndServices.addActionListener(this);
		
		btnTermsAndServices.setBackground(Color.LIGHT_GRAY);
		btnTermsAndServices.setFont(new Font("Lucida Grande", Font.PLAIN, 11));
		btnTermsAndServices.setForeground(Color.BLUE);
		btnTermsAndServices.setOpaque(true);
		//if()
		//btnTermsAndServices.setVisible(aFlag);
		//btnTermsAndServices.setBackground(Color.black);
		btnTermsAndServices.setBounds(250, 185, 150, 29);
		frame.getContentPane().add(btnTermsAndServices);
		
		JRadioButton signUpRadio = new JRadioButton("SIGN UP !");
		signUpRadio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//e.getSource()
				
			}
		});
		signUpRadio.setFont(new Font("Lucida Grande", Font.PLAIN, 12));
		signUpRadio.setBounds(6, 66, 141, 23);
		frame.getContentPane().add(signUpRadio);
		
		JRadioButton LogInRadio = new JRadioButton("LOG IN");
		LogInRadio.setFont(new Font("Lucida Grande", Font.PLAIN, 12));
		LogInRadio.setBounds(6, 97, 141, 23);
		frame.getContentPane().add(LogInRadio);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource()==btnTermsAndServices) {
			try {
				TermsAndServices window = new TermsAndServices();
				window.frame.setVisible(true);
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
	}
}
