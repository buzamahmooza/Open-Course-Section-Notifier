import java.awt.EventQueue;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;

public class TermsAndServices {

	JFrame frame;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TermsAndServices window = new TermsAndServices();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public TermsAndServices() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 950, 600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JScrollPane scrollBar = new JScrollPane();
		//scrollBar.setLayout(null);
		
		JTextArea area = new JTextArea ( 550, 100 );
		area.setColumns(900);
		
	    area.setEditable ( true ); // set textArea non-editable
	    scrollBar = new JScrollPane ( area );
	    scrollBar.setVerticalScrollBarPolicy ( ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS );
		scrollBar.setBounds(29, 31, 900, 550);
		
		String termsAndServices = null;
		
		try {
			 termsAndServices = returnThisFile("TermsAndServices");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
//		System.out.println(termsAndServices);
		area.setText(termsAndServices);
		
		frame.getContentPane().add(scrollBar);
		
		
	}
	
	public static String returnThisFile(String str) throws FileNotFoundException, IOException {
		try (BufferedReader br = new BufferedReader(new FileReader(str))) {
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();

			while (line != null) {
				sb.append(line);
				sb.append(System.lineSeparator());
				line = br.readLine();
			}
			String everything = sb.toString();
			return everything;
		}
	}
}
